# Bat fact source notes

The app contains the 14 facts retained after removing original list items 7, 8, 14, 16, 18 and 19.

These are intended as short pupil-facing facts, so the app displays concise paraphrases rather than citations. Authoritative source notes are kept here for maintenance.

1. **Bats are the only mammals capable of true powered flight.**
   - Smithsonian Institution, Bat Facts: https://www.si.edu/spotlight/bats/batfacts
   - Smithsonian National Air and Space Museum, “Bats!”: https://airandspace.si.edu/stories/editorial/bats

2. **There are more than 1,400 species of bat in the world.**
   - Bat Conservation International FAQ: https://www.batcon.org/about-bats/faq/
   - Smithsonian NMNH notes about roughly 1,440 species: https://naturalhistory.si.edu/visit/accessibility/audio-and-visual-description/lights-out-visual-description-highlights-tour

3. **Bats live on every continent except Antarctica.**
   - Bat Conservation International FAQ: https://www.batcon.org/about-bats/faq/

4. **Chiroptera means “hand-wing”; bat wings are supported by elongated finger bones.**
   - Smithsonian Institution, Bat Facts: https://www.si.edu/spotlight/bats/batfacts

5. **Bats have existed for more than 50 million years.**
   - U.S. Geological Survey, Species We Study: Bats: https://www.usgs.gov/programs/species-management-research-program/science/species-we-study-bats

6. **Bats are not blind; many have very sensitive dim-light vision.**
   - U.S. Geological Survey, Are bats blind?: https://www.usgs.gov/faqs/are-bats-blind

7. **A bat closing in on prey can make calls faster and faster in a feeding buzz.**
   - U.S. National Park Service, Echolocation: https://www.nps.gov/subjects/bats/echolocation.htm

8. **Different bat species have different call patterns, and recordings can help scientists study/identify them.**
   - U.S. National Park Service, Echolocation: https://www.nps.gov/subjects/bats/echolocation.htm
   - NPS, Recording Echolocation Calls: https://www.nps.gov/articles/recording-echolocation-calls-of-bats-in-cabrillo.htm

9. **Bat diets include insects, fruit, nectar, fish and other foods.**
   - Bat Conservation International FAQ: https://www.batcon.org/about-bats/faq/

10. **Only three of the 1,400+ bat species are vampire bats that feed on blood.**
    - Bat Conservation International FAQ: https://www.batcon.org/about-bats/faq/

11. **Some bats are important pollinators.**
    - Bat Conservation International FAQ: https://www.batcon.org/about-bats/faq/
    - NPS, Lesser Long-nosed Bat: https://www.nps.gov/articles/lesser-long-nose-bat.htm

12. **Lesser long-nosed bats can have tongues as long as their bodies.**
    - U.S. National Park Service, Lesser Long-nosed Bat: https://www.nps.gov/articles/lesser-long-nose-bat.htm

13. **Baby bats are called pups.**
    - Bat Conservation International FAQ: https://www.batcon.org/about-bats/faq/

14. **A Siberian bat was recaptured at least 41 years after it was first banded.**
    - Bat Conservation International, Long Live Bats!: https://www.batcon.org/long-live-bats-2/
