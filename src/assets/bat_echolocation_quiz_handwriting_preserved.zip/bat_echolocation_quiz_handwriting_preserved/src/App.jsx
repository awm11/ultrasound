import React from "react";
import BatEcholocationQuiz from "./components/BatEcholocationQuiz.jsx";

export default function App() {
  return (
    <main
      style={{
        minHeight: "100vh",
        margin: 0,
        padding: 16,
        background: "#07111c",
        boxSizing: "border-box",
      }}
    >
      <BatEcholocationQuiz />
    </main>
  );
}
