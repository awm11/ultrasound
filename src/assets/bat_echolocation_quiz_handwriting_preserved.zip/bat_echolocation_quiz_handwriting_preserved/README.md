# Bat Echolocation Quiz

A ready-to-run React/Vite version of the landscape echolocation quiz.

## Included behaviour

- 8 numerical speed-distance-time questions.
- The first 3 questions are bat echolocation questions.
- Formula shown once at the top: `distance = ½ × speed × time`.
- Speed of sound fixed at `340 m/s` throughout.
- Students find either distance or time.
- Handwriting is the default answer method. Students write directly in a large **Write your answer** box. Their ink stays exactly where they wrote it; recognition is shown separately underneath and never replaces the handwriting. On compatible Chromium/Edge devices the quiz first uses the device handwriting recogniser, with the bundled digit recogniser as a fallback. A **Type answer** button opens an in-app numeric keypad as the universal fallback, with no extra window or OS keyboard required.
- **Previous question** and **Next question** navigation.
- Per-question stylus/mouse/finger working area with a light-grey grid.
- Stylus eraser support where the browser/device exposes the eraser through Pointer Events.
- Working persists while the component remains mounted and is cleared by a page refresh.
- Left/right swap button sits directly over the boundary between the question and working panels.
- When swapped, the question panel keeps its original width and the working panel keeps its original width.
- A reward screen appears after questions 2, 4, 6 and 8.
- On first load, 4 unique bat pictures and 4 unique bat facts are chosen in advance, so there are no duplicates during a quiz run.
- The final reward shows the overall score.

## Bat images

Replace the 10 placeholder files in `src/assets/` with your own photos, keeping these exact filenames:

- `bat_1.jpg`
- `bat_2.jpg`
- `bat_3.jpg`
- `bat_4.jpg`
- `bat_5.jpg`
- `bat_6.jpg`
- `bat_7.jpg`
- `bat_8.jpg`
- `bat_9.jpg`
- `bat_10.jpg`

The quiz imports those ten files directly.

## Run the standalone preview

```bash
npm install
npm run dev
```

Then open the local address printed by Vite.

## Add to an existing React project

Copy:

- `src/components/BatEcholocationQuiz.jsx`
- `src/components/BatEcholocationQuiz.css`
- `src/components/digitRecognizer.js`
- the ten `src/assets/bat_*.jpg` images

Then render:

```jsx
import BatEcholocationQuiz from "./components/BatEcholocationQuiz";

function YourPage() {
  return <BatEcholocationQuiz />;
}
```

If your containing popup has a close/finish action, pass it as `onFinish`:

```jsx
<BatEcholocationQuiz onFinish={() => setQuizOpen(false)} />
```

The **Finish** button is only shown on the final reward screen when `onFinish` is supplied.

## Notes

The layout is primarily designed for a horizontal/landscape screen. It also collapses to a single-column layout below 900px.

The question and reward state is intentionally in-memory only. Refreshing the page starts a new quiz run and generates a new non-repeating set of four reward images and facts.

## Answer entry

Handwriting is deliberately the default:

- **Pen/stylus:** write the number directly in the large white **Write your answer** box. The ink remains visible in the box. After a short pause, the quiz prints **Recognised: …** underneath; it does not replace or erase the handwriting.
- **Finger or mouse:** the same handwriting box also accepts touch and left-mouse strokes, which is useful on devices that do not report a stylus as a pen pointer.
- **Type answer:** this secondary button switches the answer area to a built-in 0–9 decimal keypad with backspace. The keypad is part of the quiz itself, so it does not depend on the operating system showing a touch keyboard.
- **Physical keyboard:** the typed answer field still accepts normal keyboard entry.
- **Clear:** available in both entry modes.
- **Stylus eraser:** where the device exposes the eraser through Pointer Events, using it in the handwriting box clears the current answer.
- **Recognition:** where the Chromium Handwriting Recognition API is available, the quiz uses the device recogniser with a numerical-input hint. If that API is unavailable or does not produce a usable number, the bundled recogniser in `src/components/digitRecognizer.js` is used. No network OCR service is required.

The handwritten strokes are never replaced by the recognised value. The recognised value is shown on its own line below the writing box before **Check answer**. If recognition is wrong, the student can press **Clear** and rewrite, or tap **Type answer**. Decimal commas entered from a physical keyboard are still accepted and normalised to decimal points when checking.

This keeps the pen interaction primary while ensuring the quiz still works on devices with no pen support at all.
